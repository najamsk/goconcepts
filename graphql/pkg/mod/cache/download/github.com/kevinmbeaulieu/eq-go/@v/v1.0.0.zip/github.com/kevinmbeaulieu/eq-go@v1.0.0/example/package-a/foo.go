package package_a

const aConst = 123

var anIntVar int = 4
