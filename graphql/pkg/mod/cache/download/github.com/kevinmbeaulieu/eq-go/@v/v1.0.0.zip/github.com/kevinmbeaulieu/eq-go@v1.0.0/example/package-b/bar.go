package package_b

const aConst = 123

var anIntVar int = 4
