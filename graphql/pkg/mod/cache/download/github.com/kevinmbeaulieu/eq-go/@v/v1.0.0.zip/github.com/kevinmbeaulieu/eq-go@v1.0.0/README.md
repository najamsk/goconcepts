# eq[uivalent]-go
Check whether two Go source directories contain equivalent code.

