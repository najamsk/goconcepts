package remote_api

type User struct {
	Name  string
	Likes []string
}
