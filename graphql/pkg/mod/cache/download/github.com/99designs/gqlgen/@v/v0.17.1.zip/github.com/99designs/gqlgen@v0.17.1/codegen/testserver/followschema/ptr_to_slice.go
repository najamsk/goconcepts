package followschema

type PtrToSliceContainer struct {
	PtrToSlice *[]string
}
