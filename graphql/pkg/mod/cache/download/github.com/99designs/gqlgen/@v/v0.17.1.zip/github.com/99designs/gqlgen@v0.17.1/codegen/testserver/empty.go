package testserver

// Empty file to silence go build error complaining that codegen/testserver/ has no non-test Go source files.
