---
linkTitle: Introduction
title: Type-safe GraphQL for Go
type: homepage
date: 2018-03-17T13:06:47+11:00
---
