### What happened?

### What did you expect?

### Minimal graphql.schema and models to reproduce

### versions
 - `go run github.com/99designs/gqlgen version`?
 - `go version`?
