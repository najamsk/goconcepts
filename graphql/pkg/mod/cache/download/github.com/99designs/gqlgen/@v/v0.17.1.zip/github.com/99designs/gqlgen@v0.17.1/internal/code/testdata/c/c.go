package c

import (
	"github.com/99designs/gqlgen/internal/code/testdata/b"
)

var C = b.B + " C"
