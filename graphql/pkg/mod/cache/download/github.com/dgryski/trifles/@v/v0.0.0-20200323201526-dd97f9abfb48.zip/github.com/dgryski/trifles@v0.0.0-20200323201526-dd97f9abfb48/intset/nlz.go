package main

func nlz(x uint32) uint32
