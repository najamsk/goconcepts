package numerical

func rdtsc() uint64
