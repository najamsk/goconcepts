package main

func nlz(x uint64) uint64
