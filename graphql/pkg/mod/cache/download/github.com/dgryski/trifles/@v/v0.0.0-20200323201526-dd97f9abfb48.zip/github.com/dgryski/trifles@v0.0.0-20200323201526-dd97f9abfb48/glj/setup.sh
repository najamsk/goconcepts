#!/bin/sh
curl -s -O https://raw.githubusercontent.com/antirez/lua-cmsgpack/master/lua_cmsgpack.c
